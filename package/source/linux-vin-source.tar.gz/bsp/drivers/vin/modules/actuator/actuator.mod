/home/onyx/linux-vin/bsp/drivers/vin/modules/actuator/actuator.o

