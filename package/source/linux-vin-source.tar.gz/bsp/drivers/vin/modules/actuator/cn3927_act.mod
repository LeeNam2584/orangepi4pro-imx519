/home/onyx/linux-vin/bsp/drivers/vin/modules/actuator/cn3927_act.o

