/home/onyx/linux-vin/bsp/drivers/vin/modules/sensor/gc030a_mipi.o

