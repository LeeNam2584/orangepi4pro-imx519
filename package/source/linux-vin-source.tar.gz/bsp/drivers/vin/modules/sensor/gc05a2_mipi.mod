/home/onyx/linux-vin/bsp/drivers/vin/modules/sensor/gc05a2_mipi.o

