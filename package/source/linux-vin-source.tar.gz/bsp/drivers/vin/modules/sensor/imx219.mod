/home/onyx/linux-vin/bsp/drivers/vin/modules/sensor/imx219.o

