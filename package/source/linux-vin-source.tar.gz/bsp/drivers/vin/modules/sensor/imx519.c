/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Copyright(c) 2020 - 2026 Allwinner Technology Co.,Ltd. All rights reserved. */
/*
 * A V4L2 driver for Sony IMX519 Raw cameras on Allwinner A733 (sun60iw2).
 * Developed for Orange Pi 4 Pro by Le Quoc Nam & Nguyen Trong Nhan.
 */

#include "../../utility/vin_log.h"
#include <linux/init.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/i2c.h>
#include <linux/delay.h>
#include <linux/videodev2.h>
#include <linux/clk.h>
#include <media/v4l2-device.h>
#include <media/v4l2-mediabus.h>
#include <linux/io.h>
#include "camera.h"
#include "sensor_helper.h"

MODULE_AUTHOR("Le Quoc Nam & Nguyen Trong Nhan");
MODULE_DESCRIPTION("A low-level driver for Sony IMX519 sensors on Allwinner VIN");
MODULE_LICENSE("GPL");

#define MCLK              (24*1000*1000)
#define V4L2_IDENT_SENSOR 0x0519

#define SENSOR_FRAME_RATE 30

/* 7-bit 0x1a -> 8-bit 0x34 */
#define I2C_ADDR 0x34
#define SENSOR_NUM 0x2
#define SENSOR_NAME "imx519"
#define SENSOR_NAME_2 "imx519_2"

static int imx519_sensor_vts = 0x049c;
static bool keep_power_on_probe_failure;
static bool imx519_detected;
static int test_pattern;

module_param(keep_power_on_probe_failure, bool, 0644);
MODULE_PARM_DESC(keep_power_on_probe_failure,
		 "Keep CAM1 clock and reset released after a failed probe for I2C diagnostics");
module_param(test_pattern, int, 0644);
static int default_exposure = 1000;
static int default_gain = 768;
module_param(default_exposure, int, 0644);
MODULE_PARM_DESC(default_exposure, "IMX519 default exposure lines (1-1180)");
module_param(default_gain, int, 0644);
MODULE_PARM_DESC(default_gain, "IMX519 default analog gain code (0-960, 768=4x)");
MODULE_PARM_DESC(test_pattern,
		 "IMX519 test pattern: 0=off, 1=solid, 2=color bars, 3=grey, 4=PN9");

static struct regval_list sensor_default_regs[] = {
};

static struct regval_list sensor_1080p_regs[] = {
	{0x0136, 0x18},
	{0x0137, 0x00},
	{0x3C7E, 0x01},
	{0x3C7F, 0x07},
	{0x3020, 0x00},
	{0x3E35, 0x01},
	{0x3F7F, 0x01},
	{0x5609, 0x57},
	{0x5613, 0x51},
	{0x561F, 0x5E},
	{0x5623, 0xD2},
	{0x5637, 0x11},
	{0x5657, 0x11},
	{0x5659, 0x12},
	{0x5733, 0x60},
	{0x5905, 0x57},
	{0x590F, 0x51},
	{0x591B, 0x5E},
	{0x591F, 0xD2},
	{0x5933, 0x11},
	{0x5953, 0x11},
	{0x5955, 0x12},
	{0x5A2F, 0x60},
	{0x5A85, 0x57},
	{0x5A8F, 0x51},
	{0x5A9B, 0x5E},
	{0x5A9F, 0xD2},
	{0x5AB3, 0x11},
	{0x5AD3, 0x11},
	{0x5AD5, 0x12},
	{0x5BAF, 0x60},
	{0x5C15, 0x2A},
	{0x5C17, 0x80},
	{0x5C19, 0x31},
	{0x5C1B, 0x87},
	{0x5C25, 0x25},
	{0x5C27, 0x7B},
	{0x5C29, 0x2A},
	{0x5C2B, 0x80},
	{0x5C2D, 0x31},
	{0x5C2F, 0x87},
	{0x5C35, 0x2B},
	{0x5C37, 0x81},
	{0x5C39, 0x31},
	{0x5C3B, 0x87},
	{0x5C45, 0x25},
	{0x5C47, 0x7B},
	{0x5C49, 0x2A},
	{0x5C4B, 0x80},
	{0x5C4D, 0x31},
	{0x5C4F, 0x87},
	{0x5C55, 0x2D},
	{0x5C57, 0x83},
	{0x5C59, 0x32},
	{0x5C5B, 0x88},
	{0x5C65, 0x29},
	{0x5C67, 0x7F},
	{0x5C69, 0x2E},
	{0x5C6B, 0x84},
	{0x5C6D, 0x32},
	{0x5C6F, 0x88},
	{0x5E69, 0x04},
	{0x5E9D, 0x00},
	{0x5F18, 0x10},
	{0x5F1A, 0x0E},
	{0x5F20, 0x12},
	{0x5F22, 0x10},
	{0x5F24, 0x0E},
	{0x5F28, 0x10},
	{0x5F2A, 0x0E},
	{0x5F30, 0x12},
	{0x5F32, 0x10},
	{0x5F34, 0x0E},
	{0x5F38, 0x0F},
	{0x5F39, 0x0D},
	{0x5F3C, 0x11},
	{0x5F3D, 0x0F},
	{0x5F3E, 0x0D},
	{0x5F61, 0x07},
	{0x5F64, 0x05},
	{0x5F67, 0x03},
	{0x5F6A, 0x03},
	{0x5F6D, 0x07},
	{0x5F70, 0x07},
	{0x5F73, 0x05},
	{0x5F76, 0x02},
	{0x5F79, 0x07},
	{0x5F7C, 0x07},
	{0x5F7F, 0x07},
	{0x5F82, 0x07},
	{0x5F85, 0x03},
	{0x5F88, 0x02},
	{0x5F8B, 0x01},
	{0x5F8E, 0x01},
	{0x5F91, 0x04},
	{0x5F94, 0x05},
	{0x5F97, 0x02},
	{0x5F9D, 0x07},
	{0x5FA0, 0x07},
	{0x5FA3, 0x07},
	{0x5FA6, 0x07},
	{0x5FA9, 0x03},
	{0x5FAC, 0x01},
	{0x5FAF, 0x01},
	{0x5FB5, 0x03},
	{0x5FB8, 0x02},
	{0x5FBB, 0x01},
	{0x5FC1, 0x07},
	{0x5FC4, 0x07},
	{0x5FC7, 0x07},
	{0x5FD1, 0x00},
	{0x6302, 0x79},
	{0x6305, 0x78},
	{0x6306, 0xA5},
	{0x6308, 0x03},
	{0x6309, 0x20},
	{0x630B, 0x0A},
	{0x630D, 0x48},
	{0x630F, 0x06},
	{0x6311, 0xA4},
	{0x6313, 0x03},
	{0x6314, 0x20},
	{0x6316, 0x0A},
	{0x6317, 0x31},
	{0x6318, 0x4A},
	{0x631A, 0x06},
	{0x631B, 0x40},
	{0x631C, 0xA4},
	{0x631E, 0x03},
	{0x631F, 0x20},
	{0x6321, 0x0A},
	{0x6323, 0x4A},
	{0x6328, 0x80},
	{0x6329, 0x01},
	{0x632A, 0x30},
	{0x632B, 0x02},
	{0x632C, 0x20},
	{0x632D, 0x02},
	{0x632E, 0x30},
	{0x6330, 0x60},
	{0x6332, 0x90},
	{0x6333, 0x01},
	{0x6334, 0x30},
	{0x6335, 0x02},
	{0x6336, 0x20},
	{0x6338, 0x80},
	{0x633A, 0xA0},
	{0x633B, 0x01},
	{0x633C, 0x60},
	{0x633D, 0x02},
	{0x633E, 0x60},
	{0x633F, 0x01},
	{0x6340, 0x30},
	{0x6341, 0x02},
	{0x6342, 0x20},
	{0x6343, 0x03},
	{0x6344, 0x80},
	{0x6345, 0x03},
	{0x6346, 0x90},
	{0x6348, 0xF0},
	{0x6349, 0x01},
	{0x634A, 0x20},
	{0x634B, 0x02},
	{0x634C, 0x10},
	{0x634D, 0x03},
	{0x634E, 0x60},
	{0x6350, 0xA0},
	{0x6351, 0x01},
	{0x6352, 0x60},
	{0x6353, 0x02},
	{0x6354, 0x50},
	{0x6355, 0x02},
	{0x6356, 0x60},
	{0x6357, 0x01},
	{0x6358, 0x30},
	{0x6359, 0x02},
	{0x635A, 0x30},
	{0x635B, 0x03},
	{0x635C, 0x90},
	{0x635F, 0x01},
	{0x6360, 0x10},
	{0x6361, 0x01},
	{0x6362, 0x40},
	{0x6363, 0x02},
	{0x6364, 0x50},
	{0x6368, 0x70},
	{0x636A, 0xA0},
	{0x636B, 0x01},
	{0x636C, 0x50},
	{0x637D, 0xE4},
	{0x637E, 0xB4},
	{0x638C, 0x8E},
	{0x638D, 0x38},
	{0x638E, 0xE3},
	{0x638F, 0x4C},
	{0x6390, 0x30},
	{0x6391, 0xC3},
	{0x6392, 0xAE},
	{0x6393, 0xBA},
	{0x6394, 0xEB},
	{0x6395, 0x6E},
	{0x6396, 0x34},
	{0x6397, 0xE3},
	{0x6398, 0xCF},
	{0x6399, 0x3C},
	{0x639A, 0xF3},
	{0x639B, 0x0C},
	{0x639C, 0x30},
	{0x639D, 0xC1},
	{0x63B9, 0xA3},
	{0x63BA, 0xFE},
	{0x7600, 0x01},
	{0x79A0, 0x01},
	{0x79A1, 0x01},
	{0x79A2, 0x01},
	{0x79A3, 0x01},
	{0x79A4, 0x01},
	{0x79A5, 0x20},
	{0x79A9, 0x00},
	{0x79AA, 0x01},
	{0x79AD, 0x00},
	{0x79AF, 0x00},
	{0x8173, 0x01},
	{0x835C, 0x01},
	{0x8A74, 0x01},
	{0x8C1F, 0x00},
	{0x8C27, 0x00},
	{0x8C3B, 0x03},
	{0x9004, 0x0B},
	{0x920C, 0x6A},
	{0x920D, 0x22},
	{0x920E, 0x6A},
	{0x920F, 0x23},
	{0x9214, 0x6A},
	{0x9215, 0x20},
	{0x9216, 0x6A},
	{0x9217, 0x21},
	{0x9385, 0x3E},
	{0x9387, 0x1B},
	{0x938D, 0x4D},
	{0x938F, 0x43},
	{0x9391, 0x1B},
	{0x9395, 0x4D},
	{0x9397, 0x43},
	{0x9399, 0x1B},
	{0x939D, 0x3E},
	{0x939F, 0x2F},
	{0x93A5, 0x43},
	{0x93A7, 0x2F},
	{0x93A9, 0x2F},
	{0x93AD, 0x34},
	{0x93AF, 0x2F},
	{0x93B5, 0x3E},
	{0x93B7, 0x2F},
	{0x93BD, 0x4D},
	{0x93BF, 0x43},
	{0x93C1, 0x2F},
	{0x93C5, 0x4D},
	{0x93C7, 0x43},
	{0x93C9, 0x2F},
	{0x974B, 0x02},
	{0x995C, 0x8C},
	{0x995D, 0x00},
	{0x995E, 0x00},
	{0x9963, 0x64},
	{0x9964, 0x50},
	{0xAA0A, 0x26},
	{0xAE03, 0x04},
	{0xAE04, 0x03},
	{0xAE05, 0x03},
	{0xBC1C, 0x08},
	{0xBCF1, 0x02},
	{0x0111, 0x02},
	{0x0112, 0x0A},
	{0x0113, 0x0A},
	{0x0114, 0x01},
	{0x0342, 0x25},
	{0x0343, 0xD9},
	{0x0340, 0x04},
	{0x0341, 0x9C},
	{0x0344, 0x01},
	{0x0345, 0x98},
	{0x0346, 0x02},
	{0x0347, 0xA2},
	{0x0348, 0x10},
	{0x0349, 0x97},
	{0x034A, 0x0B},
	{0x034B, 0x15},
	{0x0220, 0x00},
	{0x0221, 0x11},
	{0x0222, 0x01},
	{0x0900, 0x01},
	{0x0901, 0x22},
	{0x0902, 0x0A},
	{0x3F4C, 0x01},
	{0x3F4D, 0x01},
	{0x4254, 0x7F},
	{0x0401, 0x00},
	{0x0404, 0x00},
	{0x0405, 0x10},
	{0x0408, 0x00},
	{0x0409, 0x00},
	{0x040A, 0x00},
	{0x040B, 0x00},
	{0x040C, 0x07},
	{0x040D, 0x80},
	{0x040E, 0x04},
	{0x040F, 0x38},
	{0x034C, 0x07},
	{0x034D, 0x80},
	{0x034E, 0x04},
	{0x034F, 0x38},
	{0x0301, 0x06},
	{0x0303, 0x04},
	{0x0305, 0x04},
	{0x0306, 0x01},
	{0x0307, 0x57},
	{0x0309, 0x0A},
	{0x030B, 0x02},
	{0x030D, 0x04},
	{0x030E, 0x01},
	{0x030F, 0x49},
	{0x0310, 0x01},
	{0x0820, 0x07},
	{0x0821, 0xB6},
	{0x0822, 0x00},
	{0x0823, 0x00},
	{0x3E20, 0x01},
	{0x3E37, 0x00},
	{0x3E3B, 0x00},
	{0x0106, 0x00},
	{0x0B00, 0x00},
	{0x3230, 0x00},
	{0x3F14, 0x01},
	{0x3F3C, 0x01},
	{0x3F0D, 0x0A},
	{0x3FBC, 0x00},
	{0x3C06, 0x00},
	{0x3C07, 0x48},
	{0x3C0A, 0x00},
	{0x3C0B, 0x00},
	{0x3F78, 0x00},
	{0x3F79, 0x40},
	{0x3F7C, 0x00},
	{0x3F7D, 0x00},
	{0x0100, 0x01}
};

static struct regval_list sensor_fmt_raw[] = {
};

static int sensor_g_exp(struct v4l2_subdev *sd, __s32 *value)
{
	struct sensor_info *info = to_state(sd);
	*value = info->exp;
	return 0;
}

static int sensor_s_exp(struct v4l2_subdev *sd, unsigned int exp_val)
{
	data_type explow, exphigh;
	struct sensor_info *info = to_state(sd);

	exp_val = (exp_val + 8) >> 4;
	if (exp_val < 1) exp_val = 1;
	if (exp_val > 0xffff) exp_val = 0xffff;

	exphigh = (unsigned char)((0xff00 & exp_val) >> 8);
	explow = (unsigned char)((0x00ff & exp_val));

	sensor_write(sd, 0x0203, explow);
	sensor_write(sd, 0x0202, exphigh);

	info->exp = exp_val;
	return 0;
}

static int sensor_g_gain(struct v4l2_subdev *sd, __s32 *value)
{
	struct sensor_info *info = to_state(sd);
	*value = info->gain;
	return 0;
}

static int sensor_s_gain(struct v4l2_subdev *sd, int gain_val)
{
	struct sensor_info *info = to_state(sd);
	data_type gainlow = 0;
	data_type gainhigh = 0;
	int gainana = 0;

	if (gain_val < 16) gain_val = 16;
	/* IMX519 analog gain: code = 1024 - (1024 / gain) */
	gainana = 1024 - (1024 * 16 / gain_val);
	if (gainana < 0) gainana = 0;
	if (gainana > 960) gainana = 960;

	gainlow = (unsigned char)(gainana & 0xff);
	gainhigh = (unsigned char)((gainana >> 8) & 0xff);

	sensor_write(sd, 0x0205, gainlow);
	sensor_write(sd, 0x0204, gainhigh);

	info->gain = gain_val;
	return 0;
}

static int sensor_s_exp_gain(struct v4l2_subdev *sd,
			     struct sensor_exp_gain *exp_gain)
{
	int shutter, frame_length;
	struct sensor_info *info = to_state(sd);
	int exp_val = exp_gain->exp_val;
	int gain_val = exp_gain->gain_val;

	shutter = exp_val / 16;
	if (shutter > imx519_sensor_vts - 4)
		frame_length = shutter + 4;
	else
		frame_length = imx519_sensor_vts;

	sensor_write(sd, 0x0341, (frame_length & 0xff));
	sensor_write(sd, 0x0340, (frame_length >> 8));

	sensor_s_exp(sd, exp_val);
	sensor_s_gain(sd, gain_val);

	info->exp = exp_val;
	info->gain = gain_val;
	return 0;
}

static int sensor_s_sw_stby(struct v4l2_subdev *sd, int on_off)
{
	if (on_off == STBY_ON)
		return sensor_write(sd, 0x0100, 0x00);
	else
		return sensor_write(sd, 0x0100, 0x01);
}

static int sensor_power(struct v4l2_subdev *sd, int on)
{
	int ret = 0;

	switch (on) {
	case STBY_ON:
		cci_lock(sd);
		ret = sensor_s_sw_stby(sd, STBY_ON);
		usleep_range(10000, 12000);
		cci_unlock(sd);
		break;
	case STBY_OFF:
		cci_lock(sd);
		usleep_range(10000, 12000);
		ret = sensor_s_sw_stby(sd, STBY_OFF);
		cci_unlock(sd);
		break;
	case PWR_ON:
		sensor_print("IMX519 PWR_ON\n");
		cci_lock(sd);
		vin_gpio_set_status(sd, PWDN, 1);
		vin_gpio_set_status(sd, RESET, 1);
		vin_gpio_write(sd, PWDN, CSI_GPIO_LOW);
		vin_gpio_write(sd, RESET, CSI_GPIO_LOW);
		usleep_range(1000, 1200);
		vin_set_mclk_freq(sd, MCLK);
		vin_set_mclk(sd, ON);
		usleep_range(10000, 12000);
		vin_gpio_write(sd, POWER_EN, CSI_GPIO_HIGH);
		vin_set_pmu_channel(sd, IOVDD, ON);
		vin_set_pmu_channel(sd, AVDD, ON);
		vin_set_pmu_channel(sd, DVDD, ON);
		vin_set_pmu_channel(sd, AFVDD, ON);
		usleep_range(10000, 12000);
		vin_gpio_write(sd, PWDN, CSI_GPIO_HIGH);
		vin_gpio_write(sd, RESET, CSI_GPIO_HIGH);
		usleep_range(30000, 31000);
		cci_unlock(sd);
		break;
	case PWR_OFF:
		sensor_print("IMX519 PWR_OFF\n");
		if (keep_power_on_probe_failure && !imx519_detected) {
			sensor_print("CAM1 diagnostic: keeping sensor powered after failed probe\n");
			break;
		}
		cci_lock(sd);
		vin_set_mclk(sd, OFF);
		vin_gpio_write(sd, POWER_EN, CSI_GPIO_LOW);
		vin_set_pmu_channel(sd, AFVDD, OFF);
		vin_set_pmu_channel(sd, DVDD, OFF);
		vin_set_pmu_channel(sd, AVDD, OFF);
		vin_set_pmu_channel(sd, IOVDD, OFF);
		usleep_range(10000, 12000);
		vin_gpio_write(sd, PWDN, CSI_GPIO_LOW);
		vin_gpio_write(sd, RESET, CSI_GPIO_LOW);
		vin_gpio_set_status(sd, RESET, 0);
		vin_gpio_set_status(sd, PWDN, 0);
		cci_unlock(sd);
		break;
	default:
		return -EINVAL;
	}
	return ret;
}

static int sensor_reset(struct v4l2_subdev *sd, u32 val)
{
	switch (val) {
	case 0:
		vin_gpio_write(sd, RESET, CSI_GPIO_HIGH);
		usleep_range(10000, 12000);
		break;
	case 1:
		vin_gpio_write(sd, RESET, CSI_GPIO_LOW);
		usleep_range(10000, 12000);
		break;
	default:
		return -EINVAL;
	}
	return 0;
}

static int sensor_detect(struct v4l2_subdev *sd)
{
	data_type id_h = 0, id_l = 0;
	int ret, attempt;

	/*
	 * CAM1 was designed for IMX219 modules.  IMX519 carrier boards are not
	 * consistent about the XCLR/PWDN polarity, so probe both idle levels.
	 * Keep the level that returns the expected chip ID.
	 */
	for (attempt = 0; attempt < 2; attempt++) {
		if (attempt) {
			ret = vin_gpio_write(sd, PWDN, CSI_GPIO_LOW);
			sensor_print("CAM1 alternate XCLR/PWDN level, gpio ret=%d\n", ret);
			usleep_range(30000, 31000);
		}

		id_h = 0;
		id_l = 0;
		ret = sensor_read(sd, 0x0016, &id_h);
		if (ret < 0) {
			sensor_err("probe %d: failed to read 0x0016: %d\n",
				   attempt + 1, ret);
			continue;
		}

		ret = sensor_read(sd, 0x0017, &id_l);
		if (ret < 0) {
			sensor_err("probe %d: failed to read 0x0017: %d\n",
				   attempt + 1, ret);
			continue;
		}

		sensor_print("probe %d: IMX519 ID 0x%02x%02x\n",
			     attempt + 1, id_h, id_l);
		if (id_h == 0x05 && id_l == 0x19) {
			imx519_detected = true;
			sensor_print("Sony IMX519 identified successfully (0x0519)!\n");
			return 0;
		}
	}

	/* Restore the normal active level before the caller powers down. */
	vin_gpio_write(sd, PWDN, CSI_GPIO_HIGH);
	sensor_err("IMX519 did not acknowledge on CAM1 at either XCLR/PWDN level\n");
	return -ENODEV;
}

static int sensor_init(struct v4l2_subdev *sd, u32 val)
{
	int ret;
	struct sensor_info *info = to_state(sd);

	sensor_dbg("sensor_init\n");
	ret = sensor_detect(sd);
	if (ret) {
		sensor_err("chip found is not an target chip.\n");
		return ret;
	}

	info->focus_status = 0;
	info->low_speed = 0;
	info->width = 1920;
	info->height = 1080;
	info->hflip = 0;
	info->vflip = 0;
	info->gain = 0;
	info->tpf.numerator = 1;
	info->tpf.denominator = 30;
	info->preview_first_flag = 1;

	return 0;
}

static long sensor_ioctl(struct v4l2_subdev *sd, unsigned int cmd, void *arg)
{
	int ret = 0;
	struct sensor_info *info = to_state(sd);

	switch (cmd) {
	case GET_CURRENT_WIN_CFG:
		if (info->current_wins != NULL) {
			memcpy(arg, info->current_wins, sizeof(*info->current_wins));
			ret = 0;
		} else {
			sensor_err("empty wins!\n");
			ret = -1;
		}
		break;
	case SET_FPS:
		break;
	case VIDIOC_VIN_SENSOR_EXP_GAIN:
		sensor_s_exp_gain(sd, (struct sensor_exp_gain *)arg);
		break;
	case VIDIOC_VIN_SENSOR_CFG_REQ:
		sensor_cfg_req(sd, (struct sensor_config *)arg);
		break;
	default:
		return -EINVAL;
	}
	return ret;
}

static struct sensor_format_struct sensor_formats[] = {
	{
		.desc = "Raw RGB Bayer SRGGB10",
		.mbus_code = MEDIA_BUS_FMT_SRGGB10_1X10,
		.regs = sensor_fmt_raw,
		.regs_size = ARRAY_SIZE(sensor_fmt_raw),
		.bpp = 1
	},
};
#define N_FMTS ARRAY_SIZE(sensor_formats)

static struct sensor_win_size sensor_win_sizes[] = {
	{
		.width = 1920,
		.height = 1080,
		.hoffset = 0,
		.voffset = 0,
		.hts = 0x25d9,
		.vts = 0x049c,
		.pclk = 182 * 1000 * 1000,
		.mipi_bps = 720 * 1000 * 1000,
		.fps_fixed = 1,
		.bin_factor = 1,
		.intg_min = 1 << 4,
		.intg_max = (0x049c - 32) << 4,
		.gain_min = 1 << 4,
		.gain_max = 64 << 4,
		.regs = sensor_1080p_regs,
		.regs_size = ARRAY_SIZE(sensor_1080p_regs),
		.set_size = NULL,
	},
};
#define N_WIN_SIZES (ARRAY_SIZE(sensor_win_sizes))

static int sensor_reg_init(struct sensor_info *info)
{
	int ret;
	struct v4l2_subdev *sd = &info->sd;
	struct sensor_format_struct *sensor_fmt = info->fmt;
	struct sensor_win_size *wsize = info->current_wins;

	if (!sensor_fmt || !wsize) {
		sensor_err("cannot start stream without an active format/window\n");
		return -EINVAL;
	}

	/* Configure the complete mode while the sensor remains in standby. */
	ret = sensor_write(sd, 0x0100, 0x00);
	if (ret < 0) {
		sensor_err("failed to enter standby: %d\n", ret);
		return ret;
	}

	ret = sensor_write_array(sd, sensor_default_regs,
				 ARRAY_SIZE(sensor_default_regs));
	if (ret < 0) {
		sensor_err("write sensor_default_regs error\n");
		return ret;
	}

	ret = sensor_write_array(sd, sensor_fmt->regs, sensor_fmt->regs_size);
	if (ret < 0) {
		sensor_err("write format registers error: %d\n", ret);
		return ret;
	}

	if (wsize->regs) {
		ret = sensor_write_array(sd, wsize->regs, wsize->regs_size);
		if (ret < 0) {
			sensor_err("write mode registers error: %d\n", ret);
			return ret;
		}
	}

	if (wsize->set_size) {
		ret = wsize->set_size(sd);
		if (ret < 0) {
			sensor_err("set mode size error: %d\n", ret);
			return ret;
		}
	}

	info->width = wsize->width;
	info->height = wsize->height;
	imx519_sensor_vts = wsize->vts;

	if (test_pattern >= 0 && test_pattern <= 4) {
		/* Test-pattern mode is a 16-bit big-endian register. */
		ret = sensor_write(sd, 0x0600, 0x00);
		if (!ret)
			ret = sensor_write(sd, 0x0601, test_pattern);
		if (ret < 0) {
			sensor_err("failed to set test pattern %d: %d\n",
				   test_pattern, ret);
			return ret;
		}
	}

		/* Program default exposure and analog gain so sensor is properly exposed */
	sensor_write(sd, 0x0202, (default_exposure >> 8) & 0xff);
	sensor_write(sd, 0x0203, default_exposure & 0xff);
	sensor_write(sd, 0x0204, (default_gain >> 8) & 0xff);
	sensor_write(sd, 0x0205, default_gain & 0xff);
	ret = sensor_write(sd, 0x0100, 0x01);
	if (ret < 0) {
		sensor_err("failed to start streaming: %d\n", ret);
		return ret;
	}

	sensor_print("s_fmt set width = %d, height = %d\n", info->width, info->height);
	return 0;
}

static int sensor_s_stream(struct v4l2_subdev *sd, int enable)
{
	struct sensor_info *info = to_state(sd);

	sensor_print("%s on = %d, %d*%d\n", __func__, enable,
		     info->current_wins ? info->current_wins->width : 1920,
		     info->current_wins ? info->current_wins->height : 1080);

	if (!enable) {
		return sensor_write(sd, 0x0100, 0x00);
	}
	return sensor_reg_init(info);
}

static int sensor_g_mbus_config(struct v4l2_subdev *sd, unsigned int pad,
				struct v4l2_mbus_config *cfg)
{
	cfg->type = V4L2_MBUS_CSI2_DPHY;
	cfg->flags = 0 | V4L2_MBUS_CSI2_2_LANE | V4L2_MBUS_CSI2_CHANNEL_0;
	return 0;
}

static int sensor_g_ctrl(struct v4l2_ctrl *ctrl)
{
	struct sensor_info *info =
			container_of(ctrl->handler, struct sensor_info, handler);
	struct v4l2_subdev *sd = &info->sd;

	switch (ctrl->id) {
	case V4L2_CID_GAIN:
		return sensor_g_gain(sd, &ctrl->val);
	case V4L2_CID_EXPOSURE:
		return sensor_g_exp(sd, &ctrl->val);
	}
	return -EINVAL;
}

static int sensor_s_ctrl(struct v4l2_ctrl *ctrl)
{
	struct sensor_info *info =
			container_of(ctrl->handler, struct sensor_info, handler);
	struct v4l2_subdev *sd = &info->sd;

	switch (ctrl->id) {
	case V4L2_CID_GAIN:
		return sensor_s_gain(sd, ctrl->val);
	case V4L2_CID_EXPOSURE:
		return sensor_s_exp(sd, ctrl->val);
	}
	return -EINVAL;
}

static const struct v4l2_ctrl_ops sensor_ctrl_ops = {
	.g_volatile_ctrl = sensor_g_ctrl,
	.s_ctrl = sensor_s_ctrl,
};

static const struct v4l2_subdev_core_ops sensor_core_ops = {
	.reset = sensor_reset,
	.init = sensor_init,
	.s_power = sensor_power,
	.ioctl = sensor_ioctl,
#if IS_ENABLED(CONFIG_COMPAT)
	.compat_ioctl32 = sensor_compat_ioctl32,
#endif
};

static const struct v4l2_subdev_video_ops sensor_video_ops = {
	.s_stream = sensor_s_stream,
};

static const struct v4l2_subdev_pad_ops sensor_pad_ops = {
	.enum_mbus_code = sensor_enum_mbus_code,
	.enum_frame_size = sensor_enum_frame_size,
	.get_fmt = sensor_get_fmt,
	.set_fmt = sensor_set_fmt,
	.get_mbus_config = sensor_g_mbus_config,
};

static const struct v4l2_subdev_ops sensor_ops = {
	.core = &sensor_core_ops,
	.video = &sensor_video_ops,
	.pad = &sensor_pad_ops,
};

static struct cci_driver cci_drv[] = {
	{
		.name = SENSOR_NAME,
		.addr_width = CCI_BITS_16,
		.data_width = CCI_BITS_8,
	}, {
		.name = SENSOR_NAME_2,
		.addr_width = CCI_BITS_16,
		.data_width = CCI_BITS_8,
	}
};

static int sensor_init_controls(struct v4l2_subdev *sd, const struct v4l2_ctrl_ops *ops)
{
	struct sensor_info *info = to_state(sd);
	struct v4l2_ctrl_handler *handler = &info->handler;
	struct v4l2_ctrl *ctrl;
	int ret = 0;

	v4l2_ctrl_handler_init(handler, 2);
	ctrl = v4l2_ctrl_new_std(handler, ops, V4L2_CID_EXPOSURE, 0,
			      65536 * 16, 1, 0);
	if (ctrl != NULL)
		ctrl->flags |= V4L2_CTRL_FLAG_VOLATILE;
	v4l2_ctrl_new_std(handler, ops, V4L2_CID_GAIN, 1 * 1600,
			      256 * 1600, 1, 1 * 1600);

	if (handler->error) {
		ret = handler->error;
		v4l2_ctrl_handler_free(handler);
	}
	sd->ctrl_handler = handler;
	return ret;
}

static int sensor_dev_id;
static int sensor_probe(struct i2c_client *client,
			const struct i2c_device_id *id)
{
	struct v4l2_subdev *sd;
	struct sensor_info *info;
	int i;

	info = kzalloc(sizeof(*info), GFP_KERNEL);
	if (info == NULL)
		return -ENOMEM;
	sd = &info->sd;
	if (client) {
		for (i = 0; i < SENSOR_NUM; i++) {
			if (!strcmp(cci_drv[i].name, client->name))
				break;
		}
		cci_dev_probe_helper(sd, client, &sensor_ops, &cci_drv[i]);
	} else {
		cci_dev_probe_helper(sd, client, &sensor_ops, &cci_drv[sensor_dev_id++]);
	}

	sensor_init_controls(sd, &sensor_ctrl_ops);
	mutex_init(&info->lock);

	info->fmt = &sensor_formats[0];
	info->fmt_pt = &sensor_formats[0];
	info->win_pt = &sensor_win_sizes[0];
	info->fmt_num = N_FMTS;
	info->win_size_num = N_WIN_SIZES;
	info->sensor_field = V4L2_FIELD_NONE;
	info->af_first_flag = 1;
	info->exp = 0;
	info->gain = 0;

	return 0;
}

static int sensor_remove(struct i2c_client *client)
{
	struct v4l2_subdev *sd;
	int i;

	if (client) {
		for (i = 0; i < SENSOR_NUM; i++) {
			if (!strcmp(cci_drv[i].name, client->name))
				break;
		}
		sd = cci_dev_remove_helper(client, &cci_drv[i]);
	} else {
		sd = cci_dev_remove_helper(client, &cci_drv[sensor_dev_id++]);
	}
	kfree(to_state(sd));
	return 0;
}

static const struct i2c_device_id sensor_id[] = {
	{SENSOR_NAME, 0},
	{}
};

static const struct i2c_device_id sensor_id_2[] = {
	{SENSOR_NAME_2, 0},
	{}
};

MODULE_DEVICE_TABLE(i2c, sensor_id);
MODULE_DEVICE_TABLE(i2c, sensor_id_2);

static struct i2c_driver sensor_driver[] = {
	{
		.driver = {
			.owner = THIS_MODULE,
			.name = SENSOR_NAME,
		},
		.probe = sensor_probe,
		.remove = sensor_remove,
		.id_table = sensor_id,
	}, {
		.driver = {
			.owner = THIS_MODULE,
			.name = SENSOR_NAME_2,
		},
		.probe = sensor_probe,
		.remove = sensor_remove,
		.id_table = sensor_id_2,
	},
};

static __init int init_sensor(void)
{
	int i, ret = 0;

	sensor_dev_id = 0;
	for (i = 0; i < SENSOR_NUM; i++)
		ret = cci_dev_init_helper(&sensor_driver[i]);

	return ret;
}

static __exit void exit_sensor(void)
{
	int i;

	sensor_dev_id = 0;
	for (i = 0; i < SENSOR_NUM; i++)
		cci_dev_exit_helper(&sensor_driver[i]);
}

VIN_INIT_DRIVERS(init_sensor);
module_exit(exit_sensor);
