/home/onyx/linux-vin/bsp/drivers/vin/modules/sensor/ov13850_mipi.o

